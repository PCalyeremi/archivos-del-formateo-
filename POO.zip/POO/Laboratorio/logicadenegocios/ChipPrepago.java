/***
 *esta clase es una abstracion de un ChipPrepago y si finalidad es 
 *simular su estructura y comportamiento con dines asadémicos
 *
 *@author: lpSoto
 *@version: 2.0
 */

package logicadenegocios;
import java.util.ArrayList;
import java.util.TreeSet;
import java.util.Date;
import java.util.Calendar;
import java.util.Random;
import logicadenegocios.Mensaje;
import logicadenegocios.Llamada;
import logicadenegocios.Cliente;

public class ChipPrepago {
    //atributos estaticos o de clase
    private static int cantidadChips = 0;
    private static final int CODIGO_PAIS = 506;
    public static TreeSet<Integer> contenedorNumeros = new TreeSet<Integer>();
    
    //Atributos no estaticos o de una instancia
    private double saldo;
    private int numeroTelefono;
    private String operadorCelular;
    
    //Relaciones estructurales con otras clases
    private ArrayList<Llamada> llamadas;
    private ArrayList<Mensaje> mensajes;
    private ArrayList<String> historialNavegacion;
    private Cliente duenoChip;
    
    private String numero;
    private int cantidadSalvameReizados = 0;
    private double gigaBytesDisponibles;
    private int cantidadSalvameRealizados = 0;
    private boolean chipActivado = false;
    private Date fechaActivacion;
    //--------------------------------------------------------------------
    private boolean estaActivo() {
        return (chipActivado == true);
    }
    
    private int generarParticulaInicialNumero() {
        int pNumeroInicio = 0;
        switch (operadorCelular) {
            case "Kolbi":
                pNumeroInicio = 8;
                break;
            case "Movistar" :
                pNumeroInicio = 7;
                break;
            case "Claro" :
                pNumeroInicio = 6;
                break;
            default:
                return 0;
        }
        return pNumeroInicio;
    }
    
    private int generarNumeroTelefonoRandom() {
        Random random = new Random();
        int particula = generarParticulaInicialNumero();
        if (particula != 0) {
            int numero = (int)(Math.random()*(9999999-1000000+1)+1000000);
            return (int) (particula * Math.pow(10,7)) + numero;
        }
        return 0;
    }
    
    private void agregarLlamada(Llamada pLlamada) {
        llamadas.add(pLlamada);
    }
    
    private void agregarMensaje(Mensaje pMensaje) {
        mensajes.add(pMensaje);
    }
    
    private double calcularConsumoNavegacion() {
        Random random = new Random();
        return (random.nextInt(128) +1) / 1048576;
    }
    
    private boolean esSaldoDisponible(double pMonto) {
        return (this.saldo >= pMonto);
    }
    
    private void aplicarCobro(double pMonto) {
        this.saldo = this.saldo - pMonto;
    }
    //--------------------------------------------------------------------
    
    public ChipPrepago(String pOperador, int getNumero) {
        saldo = 0;
        operadorCelular = pOperador;
        llamadas = new ArrayList<Llamada>();
        mensajes = new ArrayList<Mensaje>();
        historialNavegacion = new ArrayList<String>();
        cantidadChips ++;
        //--------------------------------------------------------------
        this.numero = String.valueOf(generarNumeroTelefonoRandom());

    }
    
    public int getNumero() {
        return numeroTelefono;
    }
    /***
     * Req 1
     */
    public void activar(Cliente pdueno, double pGigaBytesContratados ) {
        if (! estaActivo()) {
            this.chipActivado = true;
            recargar(1000);
            this.duenoChip = pdueno;
            this.gigaBytesDisponibles = pGigaBytesContratados;
            //Una relación de dependencia
            this.fechaActivacion = Calendar.getInstance().getTime();
            
            do {
                int numeroPropuesto = generarNumeroTelefonoRandom();
                if (contenedorNumeros.contains(numeroPropuesto) == false){
                    contenedorNumeros.add(numeroPropuesto);
                    numeroTelefono = numeroPropuesto;
                    break;
                }
            }
            while(true);
        }
    }
    
    public void activar(Cliente pDueno) {
        activar(pDueno, 0.0);
    }
    
    /***
     * Este permite consultar el saldo disponible del chip
     * @return saldo del chip para realizar llamadas y mensajes
     */
    /* Req 2 */
    public double consultarSaldo(){
        return this.saldo;
    }
    
    /*Req 3*/
    public double consultarDatosDisponibles() {
        return this.gigaBytesDisponibles;
    }
    
    /*Req 4*/
    public void recargarDatos(double pGigas) {
        if (estaActivo() && saldo >= 500 && saldo < 900) {
            gigaBytesDisponibles += 1;
        }   else if (estaActivo() && saldo >= 900 && saldo < 2200) {
            gigaBytesDisponibles += 2;
        } else if (estaActivo() && saldo >= 2200) {
            gigaBytesDisponibles += 5;
        }
    }
    
    /*Req 5*/
    public double recargar(double pMonto) {
        if (estaActivo() && pMonto > 0) {
            saldo= saldo + pMonto;
        }
        return saldo;
    }
    
    /*Req 6*/
    public boolean salveme() {
        if (estaActivo() && this.cantidadSalvameRealizados < 3 && saldo == 0){
            recargar(100);
            cantidadSalvameRealizados += 1;
            return true;
        }
        return false;
    }

    /*Req 7*/
    public double llamar(int pMinutos, ChipPrepago pChipDestino) {
        Llamada llamadaSaliente = new Llamada(pChipDestino.getNumero(), pMinutos, 'S');
        Llamada llamadaEntrante = new Llamada(this.getNumero(),pMinutos, 'E');
        
        if (estaActivo() && pChipDestino.estaActivo()) {
            if (pChipDestino.getNumero() != 911 && esSaldoDisponible(pMinutos * 30)) {
                aplicarCobro(pMinutos * 30);
            }
        }
        return saldo;
    }
    
    /*Req 8*/
    public ArrayList<Llamada> consultarHistorialLlamadasRealizadas() {
        ArrayList<Llamada> historialLlamadasRealizadas = new ArrayList<Llamada>();
        
        //iterar sobre una coleccion de llamadas mediante un ciclo for.
        for (Llamada llamada: llamadas) {
            if (llamada.getTipo() == 'S') {
                historialLlamadasRealizadas.add(llamada);
                
            }
        }
        return historialLlamadasRealizadas;
    }
    
    /*Req 9*/
    public ArrayList<Llamada> consutarHistorialLlamadasRealizadas(int pNumero) {
        ArrayList<Llamada> historialLlamadasRealizadas = new ArrayList<Llamada>();
        
        // Iterar sobre una coleccion de llamadas mediante unn ciclo for.
        for(Llamada llamada: llamadas) {
            if (llamada.getTipo() == 'S' && llamada.getNumero() == pNumero) {
                historialLlamadasRealizadas.add(llamada);
            }
        }
        return historialLlamadasRealizadas;
    }
    
    /*Req 10*/
    public ArrayList<Llamada> consultarHistorialLlamadasRecibidas(){
         ArrayList<Llamada> historialLlamadasEntrantes = new ArrayList<Llamada>();
         
         // Iterar sobre una coleccion de llamadas mediante un for.
         for(Llamada llamada:(llamadas)) {
             if (llamada.getTipo() == 'E') {
                 historialLlamadasEntrantes.add(llamada);
             }
         }
         return historialLlamadasEntrantes;
    }
    
    /*Req 11*/
    public ArrayList<Llamada> consultarHistorialLlamadasResividas(int pNumero) {
        ArrayList<Llamada> historialLlamadasEntrantes = new ArrayList<Llamada>();
        
        // Iterar sobre una coleccion de llamadas mediante unn ciclo for.
        for(Llamada llamada: llamadas) {
            if (llamada.getTipo() == 'E' && llamada.getNumero() == pNumero) {
                historialLlamadasEntrantes.add(llamada);
            }
        }   
        return historialLlamadasEntrantes;
        
    }
    
    /*Req 12*/
    public ArrayList<Mensaje> consultarHistorialMensajes(char pTipo) {
        ArrayList<Mensaje> historialMensajes = new ArrayList<Mensaje>();
    
        // Iterar sobre una colección de mensajes mediante un ciclo for.
        for (Mensaje mensaje : mensajes) {
            // Ajusta la condición según tus requisitos
            if (mensaje.getTipo() == pTipo) {
                historialMensajes.add(mensaje);
            }
        }
        return historialMensajes;
    }
    
    /*Req 13*/
    public boolean transferir(double pMonto, ChipPrepago pChipDestino) {
        if (estaActivo() && pChipDestino.estaActivo()) {
            aplicarCobro(pMonto+5);
            pChipDestino.recargar(pMonto);
            return true;
        }
        return false;
    }
    
    /*Req 14*/
    public double enviarMensaje(String pMensaje, ChipPrepago pChipDestino) {
        Mensaje mensajeSaliente = new Mensaje(pChipDestino.getNumero(),'S',pMensaje);
        Mensaje mensajeEntrante = new Mensaje(this.getNumero(), 'E', pMensaje);
        
        if (estaActivo() && pChipDestino.estaActivo() && pMensaje.length() <= 128) {
            if (esSaldoDisponible(20)) {
                aplicarCobro(28);
                agregarMensaje(mensajeSaliente);
                pChipDestino.agregarMensaje(mensajeEntrante);
            }
        }
        return saldo;
    }
    
    /*Req 15*/
    public void navegar(String pUrl) {
        // El usuario ha visto una URL
        if (estaActivo()) {
            double consumoGigas = calcularConsumoNavegacion();
            historialNavegacion.add(pUrl+" - consumo: " + consumoGigas);
            gigaBytesDisponibles = gigaBytesDisponibles - consumoGigas;
        }
    }
    
    //método estatico
    /*Req 16*/
    public static int consultarCantidadChips(){
        return cantidadChips;
    }
}
