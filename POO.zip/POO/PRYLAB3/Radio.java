import java.util.Random;
/**
 * 
 * 
 * @author () 
 * @version (1)
 */
public class Radio{
    //Atributos instancia
    private String marca;
    private boolean estaEncendido;
    private double frecuencia;
    private String banda;
    private int volumen;
    private Disco disco;
    
    //Atributos de clase o estaticos
    private static int cantRadios = 0;
    private static final double RANGOS_FRECUENCIA[] = new double[]{00.1, 107.5};
    private static final String BANDAS_DISPONIBLES[] = new String[] {"AM", "FM1","FM2"};
    
    public Radio(String pMarca) {
        
        marca = pMarca;
        estaEncendido = false;
        frecuencia = 00.1;
        banda = "AM";
        volumen = 0;
        //Incrementar contador de radios
        cantRadios++;
    }
    public boolean encender() {
        return(estaEncendido = true);
    }
    public boolean apagar() {
        return (estaEncendido = false);
    }
    public void cambiarFrecuencia(double pFrecuencia) {
        if (estaEncendido && verificarFrecuencia(pFrecuencia)) {
            frecuencia = pFrecuencia;
        }
    }
    public void cambiarFrecuencia() {
        Random randomObject = new Random();
        double frecuencia = 80.1 + (107.5 - 00.1) * randomObject.nextDouble();
        
        if (estaEncendido && verificarFrecuencia(frecuencia)) {
            this.frecuencia = frecuencia;
        }
    }
    public void cambiarBanda(String pBanda) {
        if (estaEncendido && verificarBanda(pBanda)) {
            banda = pBanda;
        }
    }
    private boolean verificarFrecuencia(double pFrecuencia) {
        return (pFrecuencia >= RANGOS_FRECUENCIA[0] && pFrecuencia <= RANGOS_FRECUENCIA[1]? true : false);
    }
    // NOTA
    // Para tipos primitivos el uso del operador de == funciona OK   int i = 5; i == 5 ---> v
    // Para tipos referenciados el uso de == lo que hace es compararlas direcciones de memoria los objetos
    // String cadena1 = "Luis"; String cadena2 = "Luis"; cadena1 == cadena2 ---> F
    private boolean verificarBanda(String pBanda) {
        for (String bandaActual: BANDAS_DISPONIBLES) {
            if (bandaActual.equals(pBanda)) {
                return true;
            }
    }
    return false;
    }   
    public int subirVolumen() {
        if (estaEncendido) {
            volumen+=1;
        }
        return volumen;
    }
    public int bajarVolumen() {
        if (estaEncendido) {
            volumen-=1;
        }
        return volumen;
    }
    public String reproducir() {
        if (estaEncendido && tieneDisco()) {
            return "Reproduciendo pista 1";
        }
        return "Radio is turn off | No disc.";
    }
    public String reproducir(int pPista) {
        if (estaEncendido && tieneDisco() && disco.getCantidadCanciones() <= pPista) {
            return "Reproduciendo pista 1" + pPista;
        }
        return "Radio is turn off | No disc | No valid track.";
    }
    private boolean tieneDisco()  {
        //return (disco != null? true: false);
        if (disco != null) {
            return true;
        }
        return false;
    }
    // Contexto NO esta estatico
    // Miembros estaticos (atributos y metodos) - Miembros no estaticos (atributos y metodos)
    public String insertarDisco(Disco pDisco) {
        if (estaEncendido) {
            disco = pDisco;
            return disco.toString();
        }
        return "Radio is off";
    }
    // Contexto estatico: acceder a atributos estaticos y metodos estaticos
    public static int getCantidadRadios() {
        return cantRadios;
    }
}
