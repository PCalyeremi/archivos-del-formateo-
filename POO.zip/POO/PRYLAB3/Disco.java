import java.util.ArrayList;


/**
 * Write a description of class Disco here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Disco{
    //Atributos instancias / no estaticos
    private String autor;
    private ArrayList<String> canciones;
    private static int cantidadDiscos = 0;
    
    // Metodos constructor
    // Inicializar las partes del objetivo
    public Disco(String pAutor) {
        autor = pAutor;
        canciones = new ArrayList<String>();
        cantidadDiscos++;
    }
    public void agregarCancion(String pCancion) {
        canciones.add(pCancion);
    }
    public int getCantidadCanciones() {
        return canciones.size();
    }
    
    // El metodo to String ofrece una representacion del estado de un objeto
    // accedio a valor de sus partes
    public String toString() {
        String cadena;
        
        cadena = "Autor: " + autor;
        cadena+= "\n *** Lista de canciones **** ";
        for (String cancion: canciones) {
            cadena+= ("\n + cancion");
        }
        return cadena;
    }
}