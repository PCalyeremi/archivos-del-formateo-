package logicadenegocios;

public class Cuenta {

    private int numCuenta = 0;
    private Cliente duenio = null;
    private double saldo = 0;

    public int getNumCuenta() {
        return numCuenta;
    }

    public Cliente getDuenio() {
        return duenio;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

    public void setDuenio(Cliente duenio) {
        this.duenio = duenio;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String depositar(double pMonto) {
        saldo += pMonto;
        return "El saldo actual después del depósito es : " + saldo;
    }

    private boolean validarRetiro(double pMonto) {
        return pMonto <= saldo;
    }

    public String retirar(double pMonto) {
        if (validarRetiro(pMonto)) {
            saldo -= pMonto;
            return "El saldo actual después del retiro es : " + saldo;
        } else {
            return "No tiene suficiente dinero";
        }
    }

    public String toString() {
        String msg;

        msg = "Cuenta Número: " + getNumCuenta() + "\n";
        msg += "Dueño: " + duenio.getNombre() + " " + duenio.getApellido() + "\n";
        msg += "Saldo: " + getSaldo() + "\n";
        return msg;
    }
}
