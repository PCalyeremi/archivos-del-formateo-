package logicadenegocios;


public class Estudiante
{
    public static int catidadEstudiantes = 0;
    public String nombre;
    public int edad;
    
    public boolean equals(Object o){
        if (this == o)
            return true;
        if (o == null)
            return false;
        if (getClass() != o.getClass())
            return false;
        
        Estudiante estudiante = (Estudiante) o;
        
        return nombre.equals(estudiante.nombre) && edad == estudiante.edad;
    }
}
