package logicadenegocios;


import java.util.ArrayList;

public class Cuenta {

    private int numCuenta = 0;
    private Cliente duenio = null;
    private double saldo = 0;
    private ArrayList<Operacion> operaciones;
    private int numOperaciones = 0;

    public Cuenta(Cliente pDuenio, double pMonto) {
        operaciones = new ArrayList<Operacion>();
        this.duenio = pDuenio;
        this.saldo = pMonto;
    }
    
    public int getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

    public Cliente getDuenio() {
        return duenio;
    }

    public void setDuenio(Cliente pCliente) {
        duenio = pCliente;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String depositar(double pMonto) {
        saldo += pMonto;
        Operacion nuevaOperacion = new Operacion(++numOperaciones, "deposito", pMonto);
        operaciones.add(nuevaOperacion);
        return "Saldo actual: " + saldo;
    }

    private boolean validarRetiro(double pMonto) {
        return pMonto <= saldo;
    }

    public String retirar(double pMonto) {
        if (validarRetiro(pMonto)) {
            saldo -= pMonto;
            Operacion nuevaOperacion = new Operacion(++numOperaciones, "retiro", pMonto);
            operaciones.add(nuevaOperacion);
            return "Saldo actual: " + saldo;
        } else
            return "No tiene suficiente dinero";
    }

    public String toString() {
        String msg;
        msg = "Cuenta Número: " + getNumCuenta() + "\n";
        msg += "Dueño: " + duenio.toString() + "\n";
        msg += "Saldo: " + getSaldo() + "\n";
        msg += "Registro de Operaciones:\n";
        msg += "Número\tFecha\tOperación\tMonto\n";
        for (int i = 0; i < operaciones.size(); i++) {
            Operacion unaOp = operaciones.get(i); 
            msg += unaOp.toString() + "\n";
        }
        return msg;
    }
}
