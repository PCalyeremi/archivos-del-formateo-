package logicadenegocios.aplicacion;

import logicadenegocios.Cliente;
import logicadenegocios.Cuenta;

public class AplCuenta {

    public static void main(String[] args) {
        
        Cliente cliente1 = new Cliente("134", "Bryan", "Rojas");
        Cliente cliente2 = new Cliente("356", "Alberto", "Hernández");

        Cuenta cuenta1 = new Cuenta(cliente1, 3500);
        Cuenta cuenta2 = new Cuenta(cliente2, 1700);
        
        cuenta1.depositar(1700);
        cuenta1.depositar(2200);
        cuenta1.retirar(500);
        cuenta2.retirar(400);

        System.out.println(cuenta1.toString());
        System.out.println(cuenta2.toString());
    }
}
