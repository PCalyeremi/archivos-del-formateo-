/*****Datos administrativos************************
 * Nombre del archivo: String.hpp
 * Tipo de archivo: Encabezado
 * Proyecto: libreria str
 * Autores: Yeremi Calvo,Juriel Mesen, Sidney Salazar 
 * Empresa: Instituto Tecnologio de Costa Rica 
 *****Descripción**********************************
 * Este archivo contiene la definición de la clase String,
 * que proporciona funcionalidades para el manejo de cadenas de caracteres.
 *****Versión**************************************
 * 1.0 | [8/03/2024 2:13am ] | [Yeremi Calvo,Juriel Mesen, Sidney Salazar]
 **************************************************/

#ifndef STRING_HPP
#define STRING_HPP

#include <iostream>

class String {
private:
    char *cadena; // Puntero al arreglo de caracteres
    int longitud; // Longitud de la cadena

public:
    // Constructor
    String(const char *str);

    // Destructor
    ~String();

    const char* toString() const {
        return cadena;
    }

    // Prototipos de otros métodos
    char caracterEn(int indice) const;
    int contarCaracter(char c) const;
    int ultimoIndice(char c) const;
    void cambiarCadena(const char *str);
    int len() const;
    bool operator==(const String &otro) const; // Operador de igualdad
    char** split(char separador) const;
    void concatenarEn(const char *str, int indice);
    void concatenar(const char *str);
    void concatenarCadenas(const char **strs);
    void reemplazarEn(const char *str, int indice);
    void reemplazarOcurrencias(const char *anterior, const char *nuevo);
    void guardarEnArchivo(const std::string& ruta, std::ios_base::openmode modo) const;

    void leerArchivo(const char *ruta);
};

#endif // STRING_HPP
