#include "String.hpp"
#include <iostream>

int main() {
/*
//--------------------------------------------------------------------
// implementación del constructor
//    String str1 = String((char*)"OnePiece");
    
//    str1.imprimir();
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//implementacion de destructor
    String* str = new String("Hola, mundo!");
    
    std::cout << "Cadena almacenada: " << str->toString() << std::endl;
    delete str;
    
    // Intentar imprimir la cadena nuevamente generará un error
    std::cout << "Cadena almacenada después de eliminar el objeto: " << str->toString() << std::endl;

    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
// implementación del método caracterEn()
    int indice1 = 3; // Índice para obtener el cuarto caracter
    char caracter = str1.caracterEn(indice1);

    if (caracter != '\0') {
        std::cout << "El caracter en el índice " << indice1 << " es: " << caracter << std::endl;
    } else {
        std::cout << "Índice inválido." << std::endl;
    }
//--------------------------------------------------------------------
//--------------------------------------------------------------------
// Implementacion del metodo contarCaracter
    char caracterBuscado = 'e';
    int cantidad = str1.contarCaracter(caracterBuscado);

    std::cout << "El caracter '" << caracterBuscado << "' aparece " << cantidad << " veces." << std::endl;
    
    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
// Implementación del método ultimoIndice()
//--------------------------------------------------------------------
    String str("Hola Mundo");

    // Obtener el último índice del carácter 'o'
    int ultimo_indice = str.ultimoIndice('o');

    // Imprimir el resultado
    if (ultimo_indice != -1) {
        std::cout << "El último índice de 'o' en la cadena es: " << ultimo_indice << std::endl;
    } else {
        std::cout << "'o' no se encontró en la cadena." << std::endl;
    }

    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
// Implamentacion de CambiarCadena
    String str("OnePiece");
    std::cout << "Cadena original: " << str.toString() << std::endl;

    str.cambiarCadena("");
    std::cout << "Cadena cambiada: " << str.toString() << std::endl;

    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
// Implementación del método len()
    String str("OnePiece");
    
    std::cout << "Longitud de la cadena: " << str.len() << std::endl;
    
    return 0;
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//Implementacion de equals
    String str1("Hola");
    String str2("Hola");
    String str3("Mundo");

    std::cout << "str1 == str2: " << (str1 == str2) << std::endl; // Debería imprimir true
    std::cout << "str1 == str3: " << (str1 == str3) << std::endl; // Debería imprimir false

    return 0;
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//implementacion de spilt
    String str("Hola,Mundo,Desde,CPP");

    char** subcadenas = str.split(',');

    // Imprimir las subcadenas obtenidas
    std::cout << "Subcadenas obtenidas:" << std::endl;
    for (int i = 0; subcadenas[i] != nullptr; ++i) {
        std::cout << subcadenas[i] << std::endl;
        delete[] subcadenas[i]; // Liberar memoria de cada subcadena
    }
    delete[] subcadenas; // Liberar memoria del arreglo de punteros

    return 0;
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//implementacion de concatenarEn
    String str("Hola Mundo");

    // Concatenar la cadena "desde C++" en la posición 5
    str.concatenarEn("desde C++", 5);

    // Imprimir la cadena resultante
    std::cout << "Cadena resultante: ";
    for (int i = 0; i < str.len(); ++i) {
        std::cout << str.caracterEn(i);
    }
    std::cout << std::endl;

    return 0;

//--------------------------------------------------------------------
//--------------------------------------------------------------------
//Implementacion de concatenar
    String str("Hello");
    std::cout << "Cadena original: " << str.toString() << std::endl;

    // Concatenamos una cadena al final
    str.concatenar(", world!");
    std::cout << "Después de concatenar: " << str.toString() << std::endl;

    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//Implementacion de concatenarCadenas
    String str("Hello");
    std::cout << "Cadena original: " << str.toString() << std::endl;

    // Creamos un arreglo de cadenas
    const char *cadenas[] = {" ", "world", "!", nullptr};

    // Concatenamos las cadenas al final del string original
    str.concatenarCadenas(cadenas);
    std::cout << "Después de concatenar: " << str.toString() << std::endl;

    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//Implementacion de reemplazarEn
    String str("Hello, world!");
    std::cout << "Cadena original: " << str.toString() << std::endl;

    // Reemplazamos la subcadena "world" por "John"
    str.reemplazarEn("yeremi", 7);
    std::cout << "Después de reemplazar: " << str.toString() << std::endl;

    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//Implementacion de reemplazarOcurrencias
    String str("Hello, my name is John. Hello, world!");

    // Imprimir el string original
    std::cout << "Cadena original: " << str.toString() << std::endl;

    // Reemplazar todas las ocurrencias de "Hello" por "Hi"
    str.reemplazarOcurrencias("Hello", "Hi");

    // Imprimir el string después de reemplazar
    std::cout << "Después de reemplazar: " << str.toString() << std::endl;

    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//Implementacion de guardarEnArchivo
    String str("Hello, world!");

    // Guardamos el contenido del objeto String en un archivo
    str.guardarEnArchivo("output.txt", std::ios_base::out);

    std::cout << "Contenido guardado en el archivo 'output.txt'" << std::endl;

    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//Implementacion de leerArchivo
    String str("Contenido original");
    std::cout << "Contenido original: " << str.toString() << std::endl;
    
    // Leer el contenido del archivo y actualizar el objeto String
    str.leerArchivo("output.txt");
    std::cout << "Contenido después de leer el archivo: " << str.toString() << std::endl;
    
    return 0;
//--------------------------------------------------------------------
//--------------------------------------------------------------------
*/
}
// Compilar
// bcc32c String.cpp main.cpp -o main.exe
// .\main.exe



