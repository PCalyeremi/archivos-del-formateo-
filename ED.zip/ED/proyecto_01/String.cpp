#include "String.hpp"
#include <cstring>
#include <fstream>
#include <iostream>
// Para usar funciones relacionadas con cadenas de caracteres
//------------------------------------------------------------------------------
// Constructor
String::String(const char *str) {
	longitud = strlen(str); // Obtenemos la longitud de la cadena pasada como parámetro
	cadena = new char[longitud + 1]; // Creamos un arreglo para almacenar la cadena y un espacio adicional para el carácter nulo
	strcpy(cadena, str); // Copiamos la cadena pasada como parámetro al arreglo
}
//------------------------------------------------------------------------------
// Destructor
String::~String() {
	delete[] cadena; // Liberamos la memoria reservada para la cadena
}
//------------------------------------------------------------------------------
// Método caracterEn(funciona)
char String::caracterEn(int indice) const {
	if (indice >= 0 && indice < longitud) {
		return cadena[indice];
	} else {
		return '\0';
	}
}
//------------------------------------------------------------------------------
// Método contarCaracter(funciona)
int String::contarCaracter(char c) const {
    int contador = 0;
    for (int i = 0; i < longitud; ++i) {
        if (cadena[i] == c) {
            contador++;
        }
    }
    return contador;
}
//------------------------------------------------------------------------------
//Método ultimoIndice(funciona)
int String::ultimoIndice(char c) const {
    for (int i = longitud - 1; i >= 0; --i) {
        if (cadena[i] == c) {
            return i;
        }
    }
    return -1; // Retorna -1 si el carácter no se encuentra en el string
}
//------------------------------------------------------------------------------
//Método cambiarCadena(funciona)
void String::cambiarCadena(const char *str) {
    delete[] cadena; 
    longitud = strlen(str); 
    cadena = new char[longitud + 1]; 
    strcpy(cadena, str); 
}
//------------------------------------------------------------------------------
//Método len(funciona)
int String::len() const {
    return longitud;
}
//------------------------------------------------------------------------------
//Operador equals(funciona)
bool String::operator==(const String &otro) const {
    if (longitud != otro.longitud) {
        return false;
    }
    for (int i = 0; i < longitud; ++i) {
        if (cadena[i] != otro.cadena[i]) {
            return false;
        }
    }
    return true;
}
//------------------------------------------------------------------------------
//Método split(funciona)
char** String::split(char separador) const {

    int contador = 0;
    for (int i = 0; i < longitud; ++i) {
        if (cadena[i] == separador) {
            contador++;
        }
    }

    // Se crea el arreglo de strings
    char **lista = new char*[contador + 1]; 
    int inicio = 0;
    int indice_lista = 0;

    // Recorremos el string original para separarlo
    for (int i = 0; i <= longitud; ++i) { 
        if (cadena[i] == separador || cadena[i] == '\0') {
            int longitud_subcadena = i - inicio;
            lista[indice_lista] = new char[longitud_subcadena + 1];
            strncpy(lista[indice_lista], cadena + inicio, longitud_subcadena);
            lista[indice_lista][longitud_subcadena] = '\0';
            indice_lista++;
            inicio = i + 1;
        }
    }

    lista[contador] = nullptr;

    return lista;
}
//------------------------------------------------------------------------------
//Método concatenarEn()
void String::concatenarEn(const char *str, int indice) {

    if (indice < 0) {
        indice = longitud + indice + 1;
	}

	if (indice < 0) {
		indice = 0;
	} else if (indice > longitud) {
		indice = longitud;
    }

    int nueva_longitud = longitud + strlen(str);

	char *nueva_cadena = new char[nueva_longitud + 1];

	strncpy(nueva_cadena, cadena, indice);

    strcat(nueva_cadena, str);

    strcat(nueva_cadena, cadena + indice);

    delete[] cadena;

	cadena = nueva_cadena;

	longitud = nueva_longitud;
}
//------------------------------------------------------------------------------
//Método concatenar(funciona)	
void String::concatenar(const char *str) {
    
    int nueva_longitud = longitud + strlen(str);
    
    char *nueva_cadena = new char[nueva_longitud + 1];
    
    strcpy(nueva_cadena, cadena);
    
    strcat(nueva_cadena, str);

    delete[] cadena;
    
    cadena = nueva_cadena;
    
    longitud = nueva_longitud;
}
//------------------------------------------------------------------------------
//Método concatenarCadenas(funciona)
void String::concatenarCadenas(const char **strs) {
    
    for (int i = 0; strs[i] != nullptr; ++i) {
        concatenar(strs[i]);
    }
}
//------------------------------------------------------------------------------
//Método reemplazarEn(funciona)
void String::reemplazarEn(const char *str, int indice) {
    // Si el índice es negativo, normalizarlo
    if (indice < 0) {
        indice = longitud + indice; 
        if (indice < 0) {
            indice = 0; // Si el índice es menor que cero, colocarlo al principio
        }
    } else if (indice > longitud) {
        indice = longitud; // Si el índice es mayor que la longitud, colocarlo al final
    }

    int nueva_longitud = longitud + strlen(str);

    char *nueva_cadena = new char[nueva_longitud + 1]; 
    
    strncpy(nueva_cadena, cadena, indice);
    strcat(nueva_cadena, str);
    strcat(nueva_cadena, cadena + indice);

    delete[] cadena;
    cadena = nueva_cadena;
    
    longitud = nueva_longitud;
}
//------------------------------------------------------------------------------
//Método reemplazarOcurrencias(funciona)
void String::reemplazarOcurrencias(const char *anterior, const char *nuevo) {
    int longitud_anterior = strlen(anterior);
    int longitud_nuevo = strlen(nuevo);
    
    char *ocurrencia = strstr(cadena, anterior);
    
    while (ocurrencia != nullptr) {
        int posicion = ocurrencia - cadena;
        
        // Crear una cadena temporal para almacenar el string original antes de la ocurrencia
        char *temporal = new char[posicion + 1];
        strncpy(temporal, cadena, posicion);
        temporal[posicion] = '\0'; 
        
        char *resto = strdup(ocurrencia + longitud_anterior);
        
        char *nueva_cadena = new char[posicion + longitud_nuevo + strlen(resto) + 1];
        strcpy(nueva_cadena, temporal); 
        strcat(nueva_cadena, nuevo); 
        strcat(nueva_cadena, resto);
        
        // Actualizar el string original
        delete[] cadena;
        cadena = nueva_cadena;
        
        longitud = strlen(cadena);
        
        ocurrencia = strstr(cadena + posicion + longitud_nuevo, anterior);
        
        delete[] temporal;
        delete[] resto;
    }
}
//------------------------------------------------------------------------------
//Método guardarEnArchivo(funciona)
void String::guardarEnArchivo(const std::string& ruta, std::ios_base::openmode modo) const {
    std::ofstream archivo(ruta, modo);
    if (!archivo.is_open()) {
        std::cerr << "Error al abrir el archivo: " << ruta << std::endl;
        return;
    }
    archivo << cadena;
    archivo.close();
}
//------------------------------------------------------------------------------
//Método leerArchivo()
void String::leerArchivo(const char *ruta) {
    // Abrir el archivo en modo lectura
    std::ifstream archivo(ruta);
    
    // Verificar si el archivo se abrió correctamente
    if (!archivo.is_open()) {
        std::cerr << "Error al abrir el archivo " << ruta << std::endl;
        return;
    }
    
    archivo.seekg(0, std::ios::end);
    int longitudArchivo = archivo.tellg();
    archivo.seekg(0, std::ios::beg);
    
    char *buffer = new char[longitudArchivo + 1];
    archivo.read(buffer, longitudArchivo);
    buffer[longitudArchivo] = '\0';
    
    archivo.close();
    
    cambiarCadena(buffer); // Utilizando el método cambiarCadena para actualizar el valor del objeto String
    
    delete[] buffer;
}
//------------------------------------------------------------------------------


